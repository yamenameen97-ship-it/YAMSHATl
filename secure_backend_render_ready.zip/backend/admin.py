
from flask import Blueprint

admin = Blueprint("admin", __name__)

@admin.route("/admin/health")
def health():
    return {"admin":"ok"}


from flask import Flask
from flask_cors import CORS

from auth import auth
from posts import posts
from reels import reels
from chat import chat

app = Flask(__name__)
app.secret_key = "secret"

CORS(app, supports_credentials=True)

app.register_blueprint(auth, url_prefix="/api")
app.register_blueprint(posts, url_prefix="/api")
app.register_blueprint(reels, url_prefix="/api")
app.register_blueprint(chat, url_prefix="/api")

@app.route("/")
def home():
    return {"status":"running"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

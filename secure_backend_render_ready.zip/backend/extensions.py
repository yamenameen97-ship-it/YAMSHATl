
# Placeholder for future extensions (redis, socketio, etc)

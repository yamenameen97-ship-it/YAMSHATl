# دليل النشر على Render لمشروع Yamshat

يوضح هذا الدليل خطوات نشر مشروع Yamshat على منصة Render، مع التركيز على إعداد الخدمات الأساسية مثل الواجهة الخلفية (Backend)، قاعدة البيانات (PostgreSQL)، وRedis. يهدف هذا الدليل إلى توفير إرشادات واضحة لتمكين النشر السلس والفعال.

## 1. المتطلبات الأساسية

قبل البدء، تأكد من توفر ما يلي:

*   حساب Render نشط.
*   مستودع Git (مثل GitHub أو GitLab) يحتوي على كود مشروع Yamshat.
*   فهم أساسي لـ Docker و Python و FastAPI.

## 2. إعداد الخدمات على Render

يتكون مشروع Yamshat من عدة مكونات رئيسية تتطلب إعدادًا خاصًا على Render.

### 2.1. قاعدة البيانات (PostgreSQL)

1.  **إنشاء قاعدة بيانات PostgreSQL مُدارة:**
    *   في لوحة تحكم Render، انتقل إلى `New > PostgreSQL`.
    *   اختر اسمًا لقاعدة البيانات، المنطقة، والإصدار.
    *   تأكد من اختيار خطة مناسبة لاحتياجات مشروعك.
    *   بعد الإنشاء، ستحصل على `Internal Database URL` و `External Database URL`. ستحتاج إلى `External Database URL` لمتغير البيئة `DATABASE_URL`.
2.  **تكوين الاتصال:**
    *   انسخ `External Database URL` الذي توفره Render.
    *   استخدم هذا الرابط كقيمة لمتغير البيئة `DATABASE_URL` في خدمة الواجهة الخلفية (Backend Service) الخاصة بك.

### 2.2. Redis

1.  **إنشاء خدمة Redis مُدارة:**
    *   في لوحة تحكم Render، انتقل إلى `New > Redis`.
    *   اختر اسمًا للخدمة، المنطقة، والإصدار.
    *   بعد الإنشاء، ستحصل على `Internal Redis URL` و `External Redis URL`. ستحتاج إلى `External Redis URL` لمتغير البيئة `REDIS_URL`.
2.  **تكوين الاتصال:**
    *   انسخ `External Redis URL` الذي توفره Render.
    *   استخدم هذا الرابط كقيمة لمتغير البيئة `REDIS_URL` في خدمة الواجهة الخلفية (Backend Service) الخاصة بك.

### 2.3. الواجهة الخلفية (Backend Service)

1.  **إنشاء خدمة ويب (Web Service):**
    *   في لوحة تحكم Render، انتقل إلى `New > Web Service`.
    *   اختر مستودع Git الخاص بمشروع Yamshat.
    *   **اسم الخدمة:** اختر اسمًا لخدمة الواجهة الخلفية (مثال: `yamshat-backend`).
    *   **المنطقة:** اختر نفس المنطقة التي أنشأت فيها قاعدة البيانات وRedis.
    *   **الفرع (Branch):** الفرع الذي تريد نشره (عادةً `main` أو `master`).
    *   **البيئة (Runtime):** `Docker` (نظرًا لوجود `Dockerfile` في جذر المشروع).
    *   **أمر البناء (Build Command):** لا حاجة لأمر بناء صريح إذا كان `Dockerfile` يتعامل مع التبعيات.
    *   **أمر البدء (Start Command):** `uvicorn app.main:app --host 0.0.0.0 --port $PORT` (تأكد من أن `PORT` هو متغير بيئة توفره Render تلقائيًا).
2.  **متغيرات البيئة (Environment Variables):**
    *   هذه هي الخطوة الأكثر أهمية. ستحتاج إلى إضافة جميع المتغيرات البيئية المحددة في ملف `.env.example` الذي تم إنشاؤه مسبقًا.
    *   في قسم `Environment Variables` في إعدادات خدمة الويب، أضف كل متغير وقيمته.
    *   **ملاحظة هامة:** لا تقم بنسخ ولصق ملف `.env.example` مباشرة. بدلاً من ذلك، قم بإدخال كل متغير على حدة، مع استبدال القيم النائبة (placeholders) بقيمك الفعلية (مثل `DATABASE_URL`, `REDIS_URL`, `SECRET_KEY`, مفاتيح API للمزودين).
    *   تأكد من تعيين `SECRET_KEY` إلى قيمة قوية وعشوائية.
    *   بالنسبة لـ `CORS_ORIGINS` و `FRONTEND_ORIGIN`، تأكد من تضمين عنوان URL الخاص بالواجهة الأمامية بعد نشرها على Render.
3.  **النشر (Deploy):**
    *   بعد تكوين جميع المتغيرات، انقر على `Create Web Service`.
    *   ستقوم Render بسحب الكود، بناء صورة Docker، ونشر التطبيق.

### 2.4. الواجهة الأمامية (Frontend Service) - إذا كانت منفصلة

إذا كانت الواجهة الأمامية لمشروع Yamshat منفصلة (مثل تطبيق React أو Vue)، فستحتاج إلى نشرها كخدمة ويب منفصلة أو خدمة ثابتة (Static Site) على Render.

1.  **إنشاء خدمة ويب أو خدمة ثابتة:**
    *   في لوحة تحكم Render، انتقل إلى `New > Web Service` (لتطبيق SSR) أو `New > Static Site` (لتطبيق SPA).
    *   اختر مستودع Git الخاص بالواجهة الأمامية.
    *   **أمر البناء (Build Command):** يعتمد على إطار عمل الواجهة الأمامية (مثال: `npm install && npm run build` أو `yarn install && yarn build`).
    *   **دليل النشر (Publish Directory):** الدليل الذي يتم فيه إنشاء ملفات البناء (مثال: `build` أو `dist`).
2.  **متغيرات البيئة:**
    *   أضف أي متغيرات بيئية تتطلبها الواجهة الأمامية (مثل `VITE_BACKEND_URL` الذي يشير إلى عنوان URL لخدمة الواجهة الخلفية على Render).

## 3. إعداد Celery Workers

لضمان عمل مهام الخلفية (مثل إرسال رسائل البريد الإلكتروني) بشكل صحيح، ستحتاج إلى نشر Celery Workers كخدمة عاملة (Worker Service) على Render.

1.  **إنشاء خدمة عاملة (Worker Service):**
    *   في لوحة تحكم Render، انتقل إلى `New > Worker`.
    *   اختر مستودع Git الخاص بمشروع Yamshat.
    *   **اسم الخدمة:** `yamshat-celery-worker`.
    *   **المنطقة:** نفس منطقة الخدمات الأخرى.
    *   **البيئة (Runtime):** `Docker`.
    *   **أمر البدء (Start Command):** `celery -A app.celery_app worker --loglevel=info` (تأكد من أن `app.celery_app` هو المسار الصحيح لملف Celery الخاص بك).
2.  **متغيرات البيئة:**
    *   يجب أن تحتوي خدمة العامل على نفس متغيرات البيئة الخاصة بخدمة الواجهة الخلفية، خاصة `REDIS_URL` وجميع متغيرات البريد الإلكتروني.

## 4. تشغيل Alembic Migrations

لإنشاء أو تحديث مخطط قاعدة البيانات، ستحتاج إلى تشغيل هجرات Alembic.

1.  **تشغيل الهجرات يدويًا (للنشر الأولي):**
    *   يمكنك استخدام `Render Shell` لخدمة الواجهة الخلفية لتشغيل الهجرات يدويًا.
    *   بعد نشر خدمة الواجهة الخلفية، انتقل إلى صفحة الخدمة في Render وانقر على `Shell`.
    *   نفذ الأوامر التالية:
        ```bash
        alembic upgrade head
        ```
2.  **الهجرات التلقائية (متقدم):**
    *   لبيئات الإنتاج، يفضل أتمتة تشغيل الهجرات كجزء من عملية النشر. يمكن تحقيق ذلك عن طريق إضافة خطوة إلى `Dockerfile` أو `render.yaml` (إذا كنت تستخدم Infrastructure as Code) لتشغيل الهجرات قبل بدء التطبيق، أو كخطوة منفصلة في CI/CD.

## 5. المراقبة والتسجيل

توفر Render أدوات مراقبة وتسجيل مدمجة. تأكد من مراجعة السجلات بانتظام وتكوين التنبيهات لأي مشكلات.

## 6. استخدام `render.yaml` (Infrastructure as Code)

لإدارة جميع خدماتك (الواجهة الخلفية، الواجهة الأمامية، قاعدة البيانات، Redis، Celery Workers) كرمز، يمكنك استخدام ملف `render.yaml` في جذر مستودع Git الخاص بك. يتيح لك هذا تعريف جميع الموارد والتكوينات في ملف واحد، مما يسهل إدارة النشر وتكراره.

**مثال مبسط لـ `render.yaml`:**

```yaml
# render.yaml
services:
  - type: web
    name: yamshat-backend
    env: docker
    repo: https://github.com/<your-username>/yamshat.git # استبدل بمسار المستودع الخاص بك
    branch: main
    rootDir: backend # إذا كان الكود الخلفي في مجلد backend
    healthCheckPath: /health
    plan: starter # أو خطة مناسبة
    envVars:
      - key: DATABASE_URL
        fromDatabase: # اسم قاعدة البيانات التي أنشأتها
      - key: REDIS_URL
        fromService: # اسم خدمة Redis التي أنشأتها
      - key: SECRET_KEY
        generateValue: true # Render يمكنها توليد مفتاح سري لك
      # ... أضف جميع متغيرات البيئة الأخرى من .env.example
    autoDeploy: true
    startCommand: uvicorn app.main:app --host 0.0.0.0 --port $PORT

  - type: worker
    name: yamshat-celery-worker
    env: docker
    repo: https://github.com/<your-username>/yamshat.git
    branch: main
    rootDir: backend
    plan: starter
    envVars:
      - key: DATABASE_URL
        fromDatabase: # اسم قاعدة البيانات
      - key: REDIS_URL
        fromService: # اسم خدمة Redis
      # ... أضف جميع متغيرات البيئة الأخرى المطلوبة لـ Celery
    autoDeploy: true
    startCommand: celery -A app.celery_app worker --loglevel=info

databases:
  - name: yamshat-db
    plan: starter # أو خطة مناسبة

redis:
  - name: yamshat-redis
    plan: starter # أو خطة مناسبة
```

**ملاحظات حول `render.yaml`:**
*   استبدل `<your-username>/yamshat.git` بمسار مستودعك الفعلي.
*   استبدل `# اسم قاعدة البيانات التي أنشأتها` و `# اسم خدمة Redis التي أنشأتها` بالأسماء الفعلية التي اخترتها.
*   تأكد من أن `rootDir` يشير إلى المجلد الصحيح الذي يحتوي على `Dockerfile` ورمز الواجهة الخلفية.
*   يمكنك استخدام `generateValue: true` لـ `SECRET_KEY` للسماح لـ Render بتوليد مفتاح سري آمن تلقائيًا.

باتباع هذا الدليل، يمكنك نشر مشروع Yamshat بنجاح على Render والاستفادة من ميزاته لتشغيل تطبيقك على نطاق واسع.

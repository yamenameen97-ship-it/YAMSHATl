package com.socialapp.utils

import com.socialapp.BuildConfig

object UrlConfig {
    private fun sanitize(raw: String): String {
        return raw.trim()
    }

    fun apiBaseUrl(): String {
        val sanitized = sanitize(BuildConfig.BASE_URL).trimEnd('/')
        return "$sanitized/"
    }

    fun apiBaseWithoutTrailingSlash(): String = apiBaseUrl().trimEnd('/')

    fun socketUrl(): String = sanitize(BuildConfig.SOCKET_URL).trimEnd('/')

    fun webAppUrl(): String {
        val sanitized = sanitize(BuildConfig.WEB_APP_URL).trimEnd('/')
        return "$sanitized/"
    }

    fun webAppUrlWithoutTrailingSlash(): String = webAppUrl().trimEnd('/')
}
